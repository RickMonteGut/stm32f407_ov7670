# ili9341-8bit
ili9341 8bit
![9](https://user-images.githubusercontent.com/31142397/196009209-e561bf63-4a72-4c56-9b0a-2a17e3add05f.jpg)
